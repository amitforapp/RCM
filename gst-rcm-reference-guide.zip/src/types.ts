export type SectionType = '9(3)' | '9(4)' | '9(5)';
export type CategoryType = 'services' | 'goods';
export type ItcType = true | false | 'conditional';

export interface RcmItem {
  id: string;
  cat: CategoryType;
  sec: SectionType;
  name: string;
  rate: string;
  numericRate: number; // e.g. 18, 5, 12, 28
  rateType?: 'IGST' | 'CGST+SGST';
  code: string;
  notif: string;
  eff: string;
  itc: ItcType;
  note: string;
  withdrawn?: string;
  withdrawnNotif?: string;
}

export type FilterOption = 'all' | '9(3)-services' | '9(3)-goods' | '9(4)' | '9(5)';
export type StatusFilter = 'active' | 'all';
