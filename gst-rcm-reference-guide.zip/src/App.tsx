import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  Search,
  ChevronRight,
  ChevronDown,
  Info,
  Globe,
  LogOut,
  Calculator,
  Printer,
  Copy,
  Check,
  Sparkles,
  AlertTriangle,
  FileText,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  BookOpen
} from 'lucide-react';
import { RCM_DATA } from './data/rcmData';
import { RcmItem, FilterOption, StatusFilter } from './types';
import { LoginScreen } from './components/LoginScreen';
import { RcmCalculatorModal } from './components/RcmCalculatorModal';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeFilter, setActiveFilter] = useState<FilterOption>('all');
  const [activeStatus, setActiveStatus] = useState<StatusFilter>('active');
  const [searchTerm, setSearchTerm] = useState('');
  const [openRows, setOpenRows] = useState<Set<string>>(new Set());

  // Expandable Footnotes State
  const [fn1Open, setFn1Open] = useState(false);
  const [fn2Open, setFn2Open] = useState(false);

  // Modal State
  const [isCalcOpen, setIsCalcOpen] = useState(false);
  const [calcItem, setCalcItem] = useState<RcmItem | null>(null);

  // Copy Feedback Toast
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Filter Logic
  const filteredData = useMemo(() => {
    return RCM_DATA.filter((r) => {
      // Status filter
      if (activeStatus === 'active' && r.withdrawn) {
        return false;
      }

      // Category filter
      if (activeFilter === '9(4)' && r.sec !== '9(4)') return false;
      if (activeFilter === '9(5)' && r.sec !== '9(5)') return false;
      if (activeFilter === '9(3)-services' && !(r.sec === '9(3)' && r.cat === 'services'))
        return false;
      if (activeFilter === '9(3)-goods' && !(r.sec === '9(3)' && r.cat === 'goods'))
        return false;

      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const haystack = `${r.name} ${r.code} ${r.notif} ${r.note} ${r.rate} ${r.sec}`.toLowerCase();
        if (!haystack.includes(query)) return false;
      }

      return true;
    });
  }, [activeFilter, activeStatus, searchTerm]);

  // Statistics
  const stats = useMemo(() => {
    const activeItems = RCM_DATA.filter((r) => !r.withdrawn);
    return {
      total: RCM_DATA.length,
      s93Services: activeItems.filter((r) => r.sec === '9(3)' && r.cat === 'services').length,
      s93Goods: activeItems.filter((r) => r.sec === '9(3)' && r.cat === 'goods').length,
      s94: activeItems.filter((r) => r.sec === '9(4)').length,
      s95: activeItems.filter((r) => r.sec === '9(5)').length,
      withdrawn: RCM_DATA.filter((r) => r.withdrawn).length,
    };
  }, []);

  const toggleRow = (id: string) => {
    setOpenRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const expandAll = () => {
    setOpenRows(new Set(filteredData.map((r) => r.id)));
  };

  const collapseAll = () => {
    setOpenRows(new Set());
  };

  const copyRowText = (r: RcmItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const text = `GST RCM: ${r.name}\nSection: ${r.sec}\nRate: ${r.rate}\nHSN/SAC: ${r.code}\nNotification: ${r.notif}\nEffective Date: ${r.eff}\nITC Eligibility: ${r.itc === true ? 'Available' : r.itc === false ? 'Not available' : 'Conditional'}\nNotes: ${r.note}`;
    navigator.clipboard.writeText(text);
    setCopiedId(r.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const openCalculatorForItem = (r: RcmItem, e: React.MouseEvent) => {
    e.stopPropagation();
    setCalcItem(r);
    setIsCalcOpen(true);
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isLoggedIn) {
    return <LoginScreen onLoginSuccess={() => setIsLoggedIn(true)} />;
  }

  return (
    <div className="min-h-screen bg-[#F0F4F8] text-[#1E2D45] flex flex-col font-sans">
      {/* TOP HEADER BAR */}
      <header className="bg-gradient-to-r from-[#1B2B4B] via-[#243656] to-[#1a3a6b] text-white pt-8 pb-7 px-4 sm:px-6 lg:px-8 border-b border-blue-900/40 shadow-lg no-print">
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="p-2.5 bg-white/10 rounded-2xl border border-white/15 backdrop-blur-md shrink-0 shadow-inner">
                <ShieldCheck className="w-9 h-9 text-blue-300" />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 bg-blue-500/20 border border-blue-400/30 rounded-full px-3 py-0.5 text-[10px] font-bold tracking-wider text-blue-200 uppercase mb-1">
                  <span>📋 GST Reference</span>
                  <span className="text-blue-300">•</span>
                  <span>Taxpayers &amp; Professionals</span>
                </div>
                <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
                  Reverse Charge Mechanism (RCM) — Complete Category Guide
                </h1>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 self-start sm:self-center">
              <button
                onClick={() => {
                  setCalcItem(null);
                  setIsCalcOpen(true);
                }}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                title="Open Tax Liability Calculator"
              >
                <Calculator className="w-4 h-4" />
                <span className="hidden md:inline">RCM Calculator</span>
              </button>

              <button
                onClick={handlePrint}
                className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/15 transition-all flex items-center gap-1.5"
                title="Print Reference Page"
              >
                <Printer className="w-4 h-4" />
                <span className="hidden md:inline">Print / Save PDF</span>
              </button>

              <button
                onClick={() => setIsLoggedIn(false)}
                className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 font-semibold text-xs rounded-xl border border-red-400/20 transition-all"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-blue-100/75 leading-relaxed max-w-4xl">
            Every notified RCM category under GST — Section 9(3), 9(4) and 9(5) of the CGST Act, plus Section 5(3)/5(4) of the IGST Act for imports — with GST rate, HSN/SAC, governing notification, effective date and ITC eligibility. Click any row to expand full details. Informational only; always cross-check against the latest CBIC notification before applying.
          </p>
        </div>
      </header>

      {/* MAIN CONTENT WRAPPER */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 space-y-6">
        {/* SUMMARY STAT CARDS */}
        <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 no-print">
          <div
            onClick={() => {
              setActiveFilter('all');
              setActiveStatus('active');
            }}
            className={`bg-white border rounded-2xl p-3.5 shadow-sm hover:shadow-md cursor-pointer transition-all border-l-4 border-l-blue-600 ${
              activeFilter === 'all' && activeStatus === 'active' ? 'ring-2 ring-blue-500/20 bg-blue-50/30' : ''
            }`}
          >
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Total RCM Entries
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.total}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Services, goods &amp; e-comm</div>
          </div>

          <div
            onClick={() => {
              setActiveFilter('9(3)-services');
              setActiveStatus('active');
            }}
            className={`bg-white border rounded-2xl p-3.5 shadow-sm hover:shadow-md cursor-pointer transition-all border-l-4 border-l-emerald-500 ${
              activeFilter === '9(3)-services' ? 'ring-2 ring-emerald-500/20 bg-emerald-50/30' : ''
            }`}
          >
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              §9(3) Services
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.s93Services}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Regardless of URD/RD</div>
          </div>

          <div
            onClick={() => {
              setActiveFilter('9(3)-goods');
              setActiveStatus('active');
            }}
            className={`bg-white border rounded-2xl p-3.5 shadow-sm hover:shadow-md cursor-pointer transition-all border-l-4 border-l-emerald-600 ${
              activeFilter === '9(3)-goods' ? 'ring-2 ring-emerald-500/20 bg-emerald-50/30' : ''
            }`}
          >
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              §9(3) Goods
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.s93Goods}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Cashew, silk, cotton, PSLC</div>
          </div>

          <div
            onClick={() => {
              setActiveFilter('9(4)');
              setActiveStatus('active');
            }}
            className={`bg-white border rounded-2xl p-3.5 shadow-sm hover:shadow-md cursor-pointer transition-all border-l-4 border-l-amber-500 ${
              activeFilter === '9(4)' ? 'ring-2 ring-amber-500/20 bg-amber-50/30' : ''
            }`}
          >
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              §9(4) Unregistered
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.s94}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Scrap, real estate, cement</div>
          </div>

          <div
            onClick={() => {
              setActiveFilter('9(5)');
              setActiveStatus('active');
            }}
            className={`bg-white border rounded-2xl p-3.5 shadow-sm hover:shadow-md cursor-pointer transition-all border-l-4 border-l-purple-600 ${
              activeFilter === '9(5)' ? 'ring-2 ring-purple-500/20 bg-purple-50/30' : ''
            }`}
          >
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              §9(5) E-Commerce
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.s95}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Cabs, hotel, food delivery</div>
          </div>

          <div
            onClick={() => {
              setActiveStatus('all');
            }}
            className={`bg-white border rounded-2xl p-3.5 shadow-sm hover:shadow-md cursor-pointer transition-all border-l-4 border-l-rose-500 ${
              activeStatus === 'all' ? 'ring-2 ring-rose-500/20 bg-rose-50/30' : ''
            }`}
          >
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Withdrawn Entries
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.withdrawn}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Moved to forward charge</div>
          </div>
        </section>

        {/* CONTROLS TOOLBAR */}
        <section className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm sticky top-4 z-20 space-y-3 no-print">
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by service, goods, HSN/SAC, notification, keyword…"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-10 py-2.5 text-xs sm:text-sm text-slate-800 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10 transition-all font-medium"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Expand / Collapse All */}
            <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
              <button
                onClick={expandAll}
                className="px-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 transition-all"
              >
                ⬇ Expand all
              </button>
              <button
                onClick={collapseAll}
                className="px-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 transition-all"
              >
                ⬆ Collapse all
              </button>
            </div>
          </div>

          {/* Filter Tabs & Status Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
            {/* Category Tabs */}
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: 'all', label: 'All Categories' },
                { id: '9(3)-services', label: '§9(3) Services' },
                { id: '9(3)-goods', label: '§9(3) Goods' },
                { id: '9(4)', label: '§9(4) Unregistered' },
                { id: '9(5)', label: '§9(5) E-Commerce' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id as FilterOption)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                    activeFilter === tab.id
                      ? 'bg-blue-600 text-white font-semibold shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Status Toggle */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setActiveStatus('active')}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  activeStatus === 'active'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                ✅ Currently in force
              </button>
              <button
                onClick={() => setActiveStatus('all')}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  activeStatus === 'all'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                🕓 Include withdrawn entries
              </button>
            </div>
          </div>

          {/* Results Count */}
          <div className="text-[11px] text-slate-400 font-medium pt-1">
            Showing <strong className="text-slate-700">{filteredData.length}</strong> of{' '}
            <strong className="text-slate-700">{RCM_DATA.length}</strong> RCM entries — click any row to expand full details
          </div>
        </section>

        {/* DATA DISPLAY SECTIONS */}
        {filteredData.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-400 space-y-3">
            <Info className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-medium">
              No RCM categories match your search or filter criteria.
            </p>
            <button
              onClick={() => {
                setActiveFilter('all');
                setActiveStatus('active');
                setSearchTerm('');
              }}
              className="px-4 py-2 bg-blue-50 text-blue-600 font-semibold text-xs rounded-xl hover:bg-blue-100 transition-all"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          ['9(3)', '9(4)', '9(5)'].map((sec) => {
            const groupItems = filteredData.filter((r) => r.sec === sec);
            if (groupItems.length === 0) return null;

            const groupMeta =
              sec === '9(3)'
                ? {
                    title: 'Section 9(3) — Notified Goods & Services',
                    desc: 'RCM applies regardless of the supplier’s GST registration status for these explicitly notified categories.',
                  }
                : sec === '9(4)'
                ? {
                    title: 'Section 9(4) — Triggered by Unregistered Supplier (URD)',
                    desc: 'RCM applies here specifically because the supplier is unregistered — limited to the notified categories below (the earlier blanket URD rule was suspended in 2018).',
                  }
                : {
                    title: 'Section 9(5) — E-Commerce Operator as Deemed Supplier',
                    desc: 'The e-commerce operator pays GST on behalf of the underlying service provider for these specified aggregations.',
                  };

            return (
              <div key={sec} className="space-y-3">
                {/* Section Header */}
                <div className="flex items-center gap-2.5 pt-2">
                  <h3 className="font-display font-bold text-lg text-slate-800">
                    {groupMeta.title}
                  </h3>
                  <span className="bg-blue-100 text-blue-700 font-bold text-xs px-2.5 py-0.5 rounded-full">
                    {groupItems.length}
                  </span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed -mt-1">
                  {groupMeta.desc}
                </p>

                {/* Table Container */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                          <th className="py-3 px-4 w-10">#</th>
                          <th className="py-3 px-4">Service / Goods Category</th>
                          <th className="py-3 px-4 w-24">Section</th>
                          <th className="py-3 px-4 w-24">Type</th>
                          <th className="py-3 px-4 w-28">GST Rate</th>
                          <th className="py-3 px-4 w-40">HSN / SAC</th>
                          <th className="py-3 px-4 w-24 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs">
                        {groupItems.map((r, idx) => {
                          const isOpen = openRows.has(r.id);
                          return (
                            <React.Fragment key={r.id}>
                              {/* Main Row */}
                              <tr
                                onClick={() => toggleRow(r.id)}
                                className={`cursor-pointer hover:bg-slate-50/80 transition-colors ${
                                  r.withdrawn
                                    ? 'bg-slate-50/60 opacity-75'
                                    : isOpen
                                    ? 'bg-blue-50/30'
                                    : ''
                                }`}
                              >
                                <td className="py-3.5 px-4 text-slate-400 font-semibold text-[11px]">
                                  {idx + 1}
                                </td>
                                <td className="py-3.5 px-4 font-semibold text-slate-800 leading-snug">
                                  <div className="flex items-center gap-2">
                                    <span
                                      className={`text-slate-400 transition-transform ${
                                        isOpen ? 'rotate-90 text-blue-600' : ''
                                      }`}
                                    >
                                      ▶
                                    </span>
                                    <span>{r.name}</span>
                                    {r.withdrawn && (
                                      <span className="bg-red-600 text-white font-bold text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full ml-1">
                                        Withdrawn
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="py-3.5 px-4">
                                  <span
                                    className={`px-2.5 py-1 rounded-md text-[10px] font-bold ${
                                      r.sec === '9(3)'
                                        ? 'bg-blue-100 text-blue-800'
                                        : r.sec === '9(4)'
                                        ? 'bg-amber-100 text-amber-800'
                                        : 'bg-purple-100 text-purple-800'
                                    }`}
                                  >
                                    §{r.sec}
                                  </span>
                                </td>
                                <td className="py-3.5 px-4">
                                  <span
                                    className={`px-2.5 py-1 rounded-md text-[10px] font-bold ${
                                      r.cat === 'goods'
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : 'bg-orange-100 text-orange-800'
                                    }`}
                                  >
                                    {r.cat === 'goods' ? 'Goods' : 'Services'}
                                  </span>
                                </td>
                                <td className="py-3.5 px-4 font-bold text-amber-700 whitespace-nowrap">
                                  <span className={r.rateType === 'IGST' ? 'text-purple-700' : ''}>
                                    {r.rate}
                                  </span>
                                </td>
                                <td className="py-3.5 px-4 text-slate-600 font-medium">
                                  {r.code}
                                </td>
                                <td className="py-3.5 px-4 text-right whitespace-nowrap">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      onClick={(e) => openCalculatorForItem(r, e)}
                                      className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-lg transition-all"
                                      title="Calculate Tax"
                                    >
                                      <Calculator className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      onClick={(e) => copyRowText(r, e)}
                                      className="p-1.5 text-slate-500 hover:bg-slate-200 rounded-lg transition-all"
                                      title="Copy details"
                                    >
                                      {copiedId === r.id ? (
                                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                                      ) : (
                                        <Copy className="w-3.5 h-3.5" />
                                      )}
                                    </button>
                                  </div>
                                </td>
                              </tr>

                              {/* Detail Collapsible Row */}
                              {isOpen && (
                                <tr className="bg-slate-50/90">
                                  <td colSpan={7} className="p-0 border-b border-slate-200">
                                    <div className="p-4 sm:p-6 border-l-4 border-blue-600 space-y-4">
                                      {/* Detail Grid */}
                                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                                        <div>
                                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                                            Governing Section
                                          </div>
                                          <div className="font-bold text-slate-800">
                                            {r.sec} CGST Act
                                          </div>
                                        </div>

                                        <div>
                                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                                            GST Rate
                                          </div>
                                          <div className="font-bold text-slate-800">
                                            {r.rate} {r.rateType ? `(${r.rateType})` : ''}
                                          </div>
                                        </div>

                                        <div>
                                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                                            HSN / SAC Code
                                          </div>
                                          <div className="font-bold text-slate-800">
                                            {r.code}
                                          </div>
                                        </div>

                                        <div>
                                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                                            Notification Ref
                                          </div>
                                          <div className="font-bold text-slate-800">
                                            {r.notif}
                                          </div>
                                        </div>

                                        <div>
                                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                                            Effective Date
                                          </div>
                                          <div className="font-bold text-slate-800">
                                            {r.eff}
                                          </div>
                                        </div>

                                        <div>
                                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                                            ITC to Recipient
                                          </div>
                                          <div className="font-bold text-slate-800 flex items-center gap-1">
                                            {r.itc === true ? (
                                              <span className="text-emerald-700 flex items-center gap-1">
                                                <CheckCircle2 className="w-3.5 h-3.5" /> Available
                                              </span>
                                            ) : r.itc === false ? (
                                              <span className="text-red-600 flex items-center gap-1">
                                                <XCircle className="w-3.5 h-3.5" /> Not available
                                              </span>
                                            ) : (
                                              <span className="text-amber-700 flex items-center gap-1">
                                                <Clock className="w-3.5 h-3.5" /> Conditional
                                              </span>
                                            )}
                                          </div>
                                        </div>
                                      </div>

                                      {/* Detailed Explanatory Note */}
                                      <div className="bg-white border border-slate-200 rounded-xl p-3.5 text-xs text-slate-700 leading-relaxed shadow-2xs">
                                        <strong className="text-slate-900 block mb-1">
                                          Legal Provision &amp; Scope:
                                        </strong>
                                        {r.note}
                                      </div>

                                      {/* Withdrawn Warning */}
                                      {r.withdrawn && (
                                        <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-xs text-red-800 font-medium flex items-center gap-2">
                                          <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                                          <span>
                                            <strong>Withdrawn from RCM:</strong> Effective{' '}
                                            {r.withdrawn} per {r.withdrawnNotif || 'subsequent notification'} — this category has been moved to Forward Charge.
                                          </span>
                                        </div>
                                      )}

                                      {/* Action buttons */}
                                      <div className="flex items-center gap-2 pt-1">
                                        <button
                                          onClick={(e) => openCalculatorForItem(r, e)}
                                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-sm transition-all flex items-center gap-1"
                                        >
                                          <Calculator className="w-3.5 h-3.5" />
                                          <span>Calculate RCM Tax Liability</span>
                                        </button>
                                        <button
                                          onClick={(e) => copyRowText(r, e)}
                                          className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-lg transition-all flex items-center gap-1"
                                        >
                                          <Copy className="w-3.5 h-3.5" />
                                          <span>Copy Reference Text</span>
                                        </button>
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              )}
                            </React.Fragment>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            );
          })
        )}

        {/* FOOTNOTE GUIDES */}
        <section className="space-y-3 pt-4 no-print">
          {/* Footnote 1 */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <button
              onClick={() => setFn1Open(!fn1Open)}
              className="w-full p-4 text-left font-bold text-xs sm:text-sm text-slate-800 flex items-center justify-between hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span>⚠️ How to read and apply this GST RCM Reference</span>
              </div>
              <ChevronRight
                className={`w-4 h-4 text-slate-400 transition-transform ${
                  fn1Open ? 'rotate-90 text-blue-600' : ''
                }`}
              />
            </button>

            {fn1Open && (
              <div className="p-4 pt-0 text-xs text-slate-600 leading-relaxed border-t border-slate-100 space-y-2">
                <p>
                  <strong>Section 9(3):</strong> Specified goods and services notified for RCM regardless of whether the supplier is registered or unregistered.
                </p>
                <p>
                  <strong>Section 9(4):</strong> RCM triggered specifically because the supplier is unregistered (URD), applicable only to notified categories (such as metal scrap, cement &amp; real estate shortfalls).
                </p>
                <p>
                  <strong>Section 9(5):</strong> The e-commerce operator is deemed the supplier and pays GST on behalf of the actual service provider.
                </p>
                <p className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-900">
                  <strong>Crucial Rule:</strong> RCM tax liability must ALWAYS be discharged in cash via the electronic cash ledger. It CANNOT be paid using Input Tax Credit (ITC). However, after paying cash, the recipient can generally claim ITC in the same return (GSTR-3B Table 4(A)(3)), subject to Section 17(5) restrictions.
                </p>
              </div>
            )}
          </div>

          {/* Footnote 2: Import of Services */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <button
              onClick={() => setFn2Open(!fn2Open)}
              className="w-full p-4 text-left font-bold text-xs sm:text-sm text-slate-800 flex items-center justify-between hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-purple-600" />
                <span>🌐 Import of Services — Comprehensive Quick Rules &amp; Compliance Guide</span>
              </div>
              <ChevronRight
                className={`w-4 h-4 text-slate-400 transition-transform ${
                  fn2Open ? 'rotate-90 text-purple-600' : ''
                }`}
              />
            </button>

            {fn2Open && (
              <div className="p-4 pt-0 text-xs text-slate-600 leading-relaxed border-t border-slate-100 space-y-2.5">
                <div>
                  <strong className="text-slate-900">1. Legal Basis &amp; Rate:</strong> Section 5(3) of the IGST Act read with Notification 10/2017-Integrated Tax (Rate). Rate is driven by the SAC classification of the underlying service (e.g. 18% for SaaS, cloud software, IT, or professional consulting).
                </div>
                <div>
                  <strong className="text-slate-900">2. No Self-Invoice Required:</strong> Unlike domestic RCM from an unregistered supplier, the foreign supplier's commercial invoice is sufficient documentation for claiming ITC under Rule 36(1)(b).
                </div>
                <div>
                  <strong className="text-slate-900">3. Related-Party / No-Consideration Supplies:</strong> Taxable even without consideration under Schedule I, para 4 (services between related persons/foreign parent-subsidiary/branches). Valuation governed by Rule 28 (second proviso allows invoice value = deemed Open Market Value if full ITC is available).
                </div>
                <div>
                  <strong className="text-slate-900">4. OIDAR Services (B2B vs B2C):</strong> For B2B OIDAR (cloud database, digital software, ads), the Indian registered recipient pays IGST under RCM. For B2C OIDAR to individuals, the foreign supplier must obtain simplified registration in India and pay directly.
                </div>
                <div>
                  <strong className="text-slate-900">5. Time of Supply:</strong> Earlier of (a) date of entry in the recipient's books of account, or (b) date of payment — whichever is earlier (Section 13(3) of CGST Act).
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 text-center py-6 text-xs border-t border-slate-800 mt-auto no-print">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <div className="font-semibold text-slate-200">
            GST RCM Reference Guide &amp; Tax Liability Calculator
          </div>
          <p className="text-slate-500 text-[11px] max-w-2xl mx-auto">
            Designed for Tax Practitioners, Chartered Accountants, CMAs, Corporate Tax Teams, and Taxpayers. Always cross-examine with official CBIC notifications and statutory GST Acts.
          </p>
          <div className="text-slate-600 text-[10px] pt-1">
            © CMA Amit Anant Devdhe
          </div>
        </div>
      </footer>

      {/* RCM TAX CALCULATOR MODAL */}
      <RcmCalculatorModal
        isOpen={isCalcOpen}
        onClose={() => setIsCalcOpen(false)}
        selectedItem={calcItem}
      />
    </div>
  );
}
