import React, { useState } from 'react';
import { ShieldCheck, Lock, User, AlertCircle, Sparkles, BookOpen } from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('Smart');
  const [password, setPassword] = useState('SmartAI');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim() === 'Smart' && password === 'SmartAI') {
      setError(false);
      onLoginSuccess();
    } else {
      setError(true);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1B2B4B] via-[#243656] to-[#1a3a6b] p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-md space-y-6">
        {/* Logo and Branding Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 shadow-xl mb-2">
            <ShieldCheck className="w-12 h-12 text-blue-300" />
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
            GST RCM Reference
          </h1>
          <p className="text-xs sm:text-sm text-blue-200/80 font-medium">
            Reverse Charge Mechanism — Category Guide
          </p>
        </div>

        {/* Hero Tagline */}
        <div className="text-center px-2 py-3 bg-white/5 rounded-xl border border-white/10 backdrop-blur-sm">
          <h2 className="font-display text-base text-white font-semibold">
            From Notification to Compliance—Everything About GST RCM.
          </h2>
          <p className="text-xs text-blue-100/70 mt-1 leading-relaxed">
            A comprehensive knowledge platform designed to help professionals understand, verify, and apply Reverse Charge provisions accurately.
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-2xl border border-slate-100">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-slate-800">Sign in</h2>
            <p className="text-xs text-slate-500 mt-1">
              Enter your credentials to access the reference tool
            </p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>Invalid username or password. Please try again.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Username
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10 transition-all"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10 transition-all"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm rounded-lg shadow-lg shadow-blue-600/25 transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Sign In</span>
            </button>
          </form>

          {/* Quick Demo Credentials Info */}
          <div className="mt-4 p-2.5 bg-blue-50/70 border border-blue-100 rounded-lg text-[11px] text-blue-900 flex items-center justify-between">
            <span>Pre-filled credentials: <strong>Smart</strong> / <strong>SmartAI</strong></span>
            <button
              type="button"
              onClick={() => { setUsername('Smart'); setPassword('SmartAI'); }}
              className="text-blue-700 underline font-medium hover:text-blue-900"
            >
              Fill
            </button>
          </div>
        </div>

        {/* Professional Note */}
        <div className="p-4 bg-white/5 border border-white/10 rounded-xl text-xs text-blue-100/80 leading-relaxed">
          <div className="font-bold text-blue-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5 text-[11px]">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Professional Note</span>
          </div>
          This application is designed to simplify the understanding of GST Reverse Charge Mechanism (RCM) provisions by providing structured references, search facilities, and categorized information. It is intended to assist professionals in improving productivity and decision-making while encouraging verification with the latest statutory provisions before implementation.
        </div>

        <div className="text-center text-[11px] text-white/40 tracking-wide">
          © CMA Amit Anant Devdhe
        </div>
      </div>
    </div>
  );
};
