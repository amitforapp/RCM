import React, { useState } from 'react';
import { X, Calculator, ArrowRight, AlertCircle, CheckCircle2, DollarSign } from 'lucide-react';
import { RCM_DATA } from '../data/rcmData';
import { RcmItem } from '../types';

interface RcmCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedItem?: RcmItem | null;
}

export const RcmCalculatorModal: React.FC<RcmCalculatorModalProps> = ({
  isOpen,
  onClose,
  selectedItem,
}) => {
  const [selectedId, setSelectedId] = useState<string>(
    selectedItem?.id || RCM_DATA[0].id
  );
  const [amountStr, setAmountStr] = useState<string>('100000');
  const [txType, setTxType] = useState<'inter' | 'intra'>('intra');

  if (!isOpen) return null;

  const currentItem = RCM_DATA.find((r) => r.id === selectedId) || RCM_DATA[0];
  const amount = parseFloat(amountStr) || 0;
  const ratePct = currentItem.numericRate;

  let cgst = 0;
  let sgst = 0;
  let igst = 0;
  let totalTax = 0;

  if (txType === 'inter' || currentItem.rateType === 'IGST') {
    igst = (amount * ratePct) / 100;
    totalTax = igst;
  } else {
    cgst = (amount * (ratePct / 2)) / 100;
    sgst = (amount * (ratePct / 2)) / 100;
    totalTax = cgst + sgst;
  }

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2,
    }).format(val);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600/30 rounded-xl border border-blue-400/30">
              <Calculator className="w-5 h-5 text-blue-300" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg">GST RCM Tax Liability Calculator</h3>
              <p className="text-xs text-slate-300">
                Estimate tax liability & cash payment required for RCM supplies
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Select Category */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
              Select RCM Category / Service
            </label>
            <select
              value={selectedId}
              onChange={(e) => setSelectedId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
            >
              {RCM_DATA.map((item) => (
                <option key={item.id} value={item.id}>
                  [§{item.sec}] {item.name} ({item.rate}) — {item.code}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Amount Input */}
            <div>
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                Invoice Amount / Value (₹)
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                  ₹
                </span>
                <input
                  type="number"
                  min="0"
                  step="1000"
                  value={amountStr}
                  onChange={(e) => setAmountStr(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-8 pr-4 py-2.5 text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            {/* Supply Type */}
            <div>
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                Supply Type
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTxType('intra')}
                  className={`py-2.5 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    txType === 'intra'
                      ? 'bg-blue-50 border-blue-600 text-blue-700 shadow-sm'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Intra-State (CGST + SGST)
                </button>
                <button
                  type="button"
                  onClick={() => setTxType('inter')}
                  className={`py-2.5 px-3 text-xs font-semibold rounded-xl border transition-all ${
                    txType === 'inter'
                      ? 'bg-blue-50 border-blue-600 text-blue-700 shadow-sm'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Inter-State (IGST)
                </button>
              </div>
            </div>
          </div>

          {/* Selected Item Detail Snapshot */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-700">Category: {currentItem.name}</span>
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-bold">
                Rate: {currentItem.rate}
              </span>
            </div>
            <div className="text-slate-500">
              Notification: <span className="text-slate-700 font-medium">{currentItem.notif}</span> | HSN/SAC:{' '}
              <span className="text-slate-700 font-medium">{currentItem.code}</span>
            </div>
          </div>

          {/* Computation Summary */}
          <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-5 space-y-4">
            <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-blue-600" />
              Tax Computation Breakdown
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {txType === 'intra' && currentItem.rateType !== 'IGST' ? (
                <>
                  <div className="bg-white p-3 rounded-xl border border-blue-100 shadow-sm">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                      CGST ({ratePct / 2}%)
                    </span>
                    <span className="text-base font-bold text-slate-800">
                      {formatCurrency(cgst)}
                    </span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-blue-100 shadow-sm">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                      SGST ({ratePct / 2}%)
                    </span>
                    <span className="text-base font-bold text-slate-800">
                      {formatCurrency(sgst)}
                    </span>
                  </div>
                </>
              ) : (
                <div className="bg-white p-3 rounded-xl border border-blue-100 shadow-sm col-span-2 sm:col-span-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    IGST ({ratePct}%)
                  </span>
                  <span className="text-base font-bold text-slate-800">
                    {formatCurrency(igst)}
                  </span>
                </div>
              )}

              <div className="bg-blue-600 text-white p-3 rounded-xl shadow-md col-span-2 sm:col-span-1">
                <span className="text-[10px] uppercase font-bold text-blue-200 block mb-1">
                  Total Tax Payable
                </span>
                <span className="text-lg font-extrabold">{formatCurrency(totalTax)}</span>
              </div>
            </div>

            {/* Compliance Guidance */}
            <div className="space-y-2 text-xs pt-2 border-t border-blue-200/80">
              <div className="flex items-start gap-2 text-slate-700">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong>Mandatory Cash Payment:</strong> RCM tax of{' '}
                  <span className="font-bold text-blue-700">{formatCurrency(totalTax)}</span> must be paid electronically in cash via GSTR-3B Table 3.1(d). You cannot use existing Input Tax Credit (ITC) to discharge this RCM liability.
                </div>
              </div>

              <div className="flex items-start gap-2 text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong>ITC Availability:</strong>{' '}
                  {currentItem.itc === true ? (
                    <span className="text-emerald-700 font-semibold">
                      Fully eligible for ITC claim in the same month’s return (GSTR-3B Table 4(A)(3)) upon cash payment and valid documentation.
                    </span>
                  ) : currentItem.itc === false ? (
                    <span className="text-red-600 font-semibold">
                      ITC NOT available to the recipient for this category.
                    </span>
                  ) : (
                    <span className="text-amber-700 font-semibold">
                      ITC is conditional (subject to Section 17(5) and project conditions).
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs rounded-xl shadow transition-all"
          >
            Close Calculator
          </button>
        </div>
      </div>
    </div>
  );
};
